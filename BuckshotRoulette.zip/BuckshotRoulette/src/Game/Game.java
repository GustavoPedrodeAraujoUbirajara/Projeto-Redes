package Game;

import java.util.*;
import java.util.ArrayList;
import java.util.List;

public class Game {
	public boolean acabouJ = false;
    private List<Player> players = new ArrayList<>();
    private int currentPlayerIndex = 0;
    private int bulletsInChamber;
    private int realBullets;
    private int fakeBullets;
    private Scanner scanner = new Scanner(System.in);

    public void addPlayer(Player player) {
        players.add(player);
    }

    public Player getCurrentPlayer() {
        return players.get(currentPlayerIndex);
    }
    
    public List<Player> getPlayers() {
        return players;
    }

    public String shoot(int targetIndex) {

        if (targetIndex < 0 || targetIndex >= players.size()) {
            return "Alvo inválido.";
        }

        Player shooter = getCurrentPlayer();
        Player target = players.get(targetIndex);

        if (!target.isAlive()) {
            return "O alvo já está morto.";
        }

        if (shooter == target) {
            return "Você não pode atirar em si mesmo.";
        }

        boolean hit = Math.random() < 0.5;

        if (hit) {
            target.kill();
            return shooter.getName() + " matou " + target.getName();
        }

        return shooter.getName() + " errou o tiro.";
    }

    public void nextTurn() {
        do {
            currentPlayerIndex = (currentPlayerIndex + 1) % players.size();
        } while (!players.get(currentPlayerIndex).isAlive());
    }

    public boolean isGameOver() {
        return players.stream().filter(Player::isAlive).count() <= 1;
    }

    public String getAlivePlayers() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < players.size(); i++) {
            Player p = players.get(i);
            sb.append(i + 1)
              .append(" - ")
              .append(p.getName())
              .append(p.isAlive() ? " (VIVO)" : " (MORTO)")
              .append("\n");
        }
        return sb.toString();
    }

    public void start() {
        boolean playAgain = true;

        while (playAgain) {

	            setupChamber();
	            int turn = 0;
	
	        while (alivePlayers() > 1) {
	            Player current = players.get(turn % players.size());
	            if (!current.isAlive()) {
	                turn++;
	                continue;
	            }
	
	            boolean extraTurn = false; // controla se o jogador pode agir novamente
	            System.out.println("\n=====================================");
	            System.out.println("É a vez de: " + current.getName());
	            printGameState();
	            System.out.println("Balas restantes no pente: " + bulletsInChamber + "\n");
	            
	            if (bulletsInChamber > 0) {
		            System.out.println("Escolha um alvo para atirar:");
		            for (int i = 0; i < players.size(); i++) {
		                Player p = players.get(i);
		                if (p.isAlive()) {
		                    System.out.println((i+1) + " - " + p.getName() + (p == current ? " (Você)" : ""));
		                }
		            }
		
		            int targetIndex = -1;
		            while (targetIndex < 0 || targetIndex >= players.size() || !players.get(targetIndex).isAlive()) {
		                System.out.print("Digite o número do alvo: ");
		                try {
		                    targetIndex = Integer.parseInt(scanner.nextLine()) - 1;
		                } catch (Exception e) {
		                    targetIndex = -1;
		                }
		            }
		
		            Player target = players.get(targetIndex);
		            extraTurn = shoot(current, target);
	            } else {
	            	setupChamber();
	            }
	
	            System.out.println("\nPressione ENTER para continuar...");
	            scanner.nextLine(); // espera o jogador apertar ENTER
	            clearScreen();
	
	            if (!extraTurn) {
	                turn++;
	            }
	        }
	
	        for (Player p : players) {
	            if (p.isAlive()) {
	            	System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣤⣦⣤⣤⣤⣿⣿⣶⣤⣤⣶⣿⡿⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣿⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣿⣶⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠧⣜⢿⣿⠉⢻⣿⢿⣿⣿⡇⢠⣭⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⢿⣿⡄⣺⣿⣤⣿⣿⣿⠛⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣻⣿⣿⣛⣿⣿⣾⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣟⣿⣿⣟⣻⣿⣿⣾⣿⣿⣃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣼⣿⣿⣿⢿⠿⠟⠿⣿⢿⡉⠉⢽⡗⣶⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⠞⠋⢉⠟⠀⠀⠀⠀⠀⠈⠀⠙⢄⠀⠉⢿⣇⠏⡵⢦⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡶⣿⣦⠖⠀⠀⠀⠀⠀⢰⣶⣤⡄⠀⠀⠀⠀⠀⠀⠉⠺⢷⠎⣸⣻⢦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⠀⠀⠀⠀⠀⠀⢀⣴⣾⣷⣿⡟⠁⠀⢀⣴⣾⣯⣿⣿⣿⣿⣧⡀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⡡⢊⡼⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⠀⠀⠀⠀⠀⣴⢏⢗⢸⠟⠃⠀⠀⢠⣾⣿⣿⡿⢿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠸⡗⣩⠞⡔⣹⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⠀⠀⠀⣠⠞⣷⢸⡸⠈⠀⠀⠀⠀⢸⣿⣿⡏⠀⣸⣿⣿⡏⠙⢿⡿⠛⠀⠀⠀⠀⠀⠀⠀⠀⠨⠵⣪⠜⡡⣻⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⠀⢀⡾⢡⣶⡟⠋⠀⠀⠀⠀⠀⠀⠈⠻⣿⣿⣶⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠚⣡⢞⡕⢡⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⠀⡞⠀⠈⠛⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠻⣿⣿⣿⣿⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⡵⢋⠔⡿⢡⣿⡀⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⣼⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡴⣣⠞⣴⣻⣿⡇⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⣴⣧⡀⠀⣿⣿⣿⠀⠹⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡔⣡⣾⢟⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣷⣤⣿⣿⣿⣀⣠⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣬⣾⢟⣵⣿⡿⣻⡇⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⢳⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⢞⣥⣿⣿⢟⡕⣹⠁⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⠈⣆⢻⣠⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠙⣿⣿⣿⠛⠋⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⢟⡻⢟⣽⡿⣋⢴⡟⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⠀⠸⡌⢿⣧⡄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣇⡠⠊⡠⢊⠔⡻⢫⠞⣡⣿⣤⣤⣤⣀⠀⠀⠀⠀⠀\r\n"
	            			+ "⠀⠀⠹⣄⠛⣷⣷⣤⣄⠀⠀⠀⠀⠀⢀⣄⡴⣢⢖⡰⢂⠔⣠⠖⣰⣦⢆⣴⣲⣿⢞⣶⠞⡴⢡⢞⠔⣡⣏⣾⣿⣿⣿⣿⣿⣿⣿⣶⣤⣄\r\n"
	            			+ "⠀⠀⠀⠈⠳⣌⠙⢿⣿⢸⣿⣷⣶⣿⣿⡾⡿⣵⢋⠔⠵⢊⡵⢮⠟⡵⣯⢞⡵⣣⡿⢃⠞⡴⡱⢋⣾⣟⣯⣭⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿\r\n"
	            			+ "⠀⠀⠀⠀⠀⠿⢷⣦⣭⣭⣭⣥⣭⣤⣤⣤⣤⣤⣤⣤⣶⣞⡒⠒⠲⠃⠌⣹⢿⡿⣷⣣⣞⣴⣟⣛⣒⣺⣿⣿⣿⣟⣷⣶⣶⠦⠤⠉⠀⠀\r\n"
	            			+ "⠀⠀⠀⠀⠀⠀⠈⠉⠹⠿⠿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣤⣤⣤⣼⣿⡟⠛⠛⠳⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
	            			+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠉⠉⡭⠿⠿⢿⣿⣶⣶⣞⣃⣀⣀⣀⡚⠛⠛⠛⠉⠉⠉⠉⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
	            	System.out.println("====================== VENCEU O JOGO! ======================");
	            	System.out.println("+1.000.000 R$ NO SEU BOLSO");
	            	System.out.println();
	            	return; // encerra a partida e volta pro Main

	            }
	        }
        }
    }

    private void setupChamber() {
        bulletsInChamber = 6;
        realBullets = 2 + new Random().nextInt(3); // 2-4 balas reais
        fakeBullets = bulletsInChamber - realBullets;
        System.out.println("\n=====================================");
        System.out.println("\n🔫 RECARREGANDO A PISTOLA!");
        System.out.println("Balas reais: " + realBullets + ", Balas falsas: " + fakeBullets + "\n");
        System.out.println(
                "⠀⠀⠀⠀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                + "⠀⠀⠀⣼⢉⣉⣹⣿⣿⡏⣉⠿⠙⠿⠉⠉⠩⠏⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⣿\r\n"
                + "⠀⠀⠀⣼⣼⣿⠿⣿⡿⣧⠤⣤⠤⠤⡤⠤⣴⣦⠤⡤⣤⣶⣶⣶⣶⣶⣶⣶⡟\r\n"
                + "⠀⠀⠀⠉⠙⣿⣷⠉⠩⠯⣭⢛⣭⡴⢿⡾⠿⢿⡶⡿⠿⠿⠿⠿⠿⠛⠛⠛⠃\r\n"
                + "⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⠯⣾⣿⠲⡸⣄⠀⠀⡓⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                + "⠀⠀⠀⠀⣸⣿⢇⡏⡀⣼⣿⡿⠛⠷⠾⠿⠶⠿⠴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                + "⠀⠀⠀⣴⣿⢫⣿⡭⣸⣧⣿⡅⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                + "⠀⢀⣾⣿⠇⠔⡣⢰⢯⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                + "⢀⣼⡿⠷⠾⠾⠾⠞⣿⡟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                + "⠀⠻⣧⣤⣤⣤⣤⣤⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                + "⠀⠀⠈⠛⠒⠒⠒⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
        );
    }

    private boolean shoot(Player shooter, Player target) {

        if (bulletsInChamber == 0) {
            System.out.println("O pente está vazio! Recarregando...\n");
            setupChamber();
        }

        bulletsInChamber--;

        // total de balas disponíveis
        int totalBullets = realBullets + fakeBullets;

        // sorteio aleatório
        int roll = (int) (Math.random() * totalBullets);

        boolean hit;

        if (roll < realBullets) {
            // bala REAL
            hit = true;
            realBullets--;
        } else {
            // bala FALSA
            hit = false;
            fakeBullets--;
        }

        printGunGraphic(hit);

        if (hit) {
            System.out.println("\n💥 BANG! " + target.getName() + " perdeu 1 vida!\n");
            target.loseLife();

            System.out.println("Balas restantes no pente: " + bulletsInChamber + "\n");
            return false; // turno acabou

        } else {
            System.out.println("\n😅 CLICK! Bala falsa, nada aconteceu.\n");

            System.out.println("Balas restantes no pente: " + bulletsInChamber + "\n");

            // se atirou em si mesmo e era falsa, ganha outro turno
            if (shooter == target) {
                System.out.println("Você atirou em si mesmo mas a bala era falsa!");
                System.out.println("Pode agir novamente.\n");
                return true; // turno extra
            }
        }

        return false;
    }

    private void printGameState() {
        System.out.println("\n--- STATUS DOS JOGADORES ---");
        for (Player p : players) {
            System.out.println(p.getName() + " | Vida: " + p.getLife() + (p.isAlive() ? "" : " ☠"));
        }
        System.out.println();
    }

    private void printGunGraphic(boolean hit) {
        if (hit) {
            System.out.println(
                    "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⢶⣶⣶⠼⣦⣤⣼⣼⡆⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠖⣯⠿⠟⠛⠻⢶⣿⣯⣿⣿⣃⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣖⣺⡿⠿⠷⠶⠒⢶⣶⠖⠀⠉⡻⢻⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠀⠀⣴⢻⣭⣫⣿⠁⠀⠀⠀⠀⠀⠀⠀⢀⣾⠃⢀⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⢀⣖⡿⠋⢙⣿⠿⢿⠿⣿⡦⠄⠀⠀⠀⣠⣾⠟⠀⠀⣼⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⢀⣰⣿⣴⣿⡿⠿⠿⠿⢿⣦⣄⠀⠀⠀⣠⣾⣿⠃⠀⢀⣸⡿⣳⣶⣲⡄⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⣾⣽⡿⣛⣵⠾⠿⠿⠷⣦⣌⠻⣷⣄⢰⣿⠟⠁⠀⢠⣾⠿⢡⣯⠸⠧⢽⣄⠀⠀⠀⠀⠀\r\n"
                    + "⠀⢸⡇⡟⣴⡿⢟⣽⣾⣿⣶⣌⠻⣧⣹⣿⡿⠋⠀⠀⠀⣾⠿⡇⣽⣿⣄⠀⠀⠉⠳⣄⢀⡀⠀\r\n"
                    + "⠀⢸⠇⢳⣿⢳⣿⣿⣿⣿⣿⣿⡆⢹⡇⣿⡇⠀⡆⣠⣼⡏⢰⣿⣿⣿⣿⣦⠀⠀⠀⠈⠳⣅⠀\r\n"
                    + "⠀⣸⡀⢸⣿⢸⣿⣿⣿⣿⣿⣿⡇⣸⡇⣿⡇⠀⡟⣻⢳⣷⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠘⣧\r\n"
                    + "⢰⡟⡿⡆⠹⣧⡙⢿⣿⣿⠿⡟⢡⣿⢷⣿⣧⠾⢠⣿⣾⣿⣿⣿⣿⣿⣿⠁⠀⠀⠀⠀⠀⠀⠘\r\n"
                    + "⠀⠻⡽⣦⠀⠈⠙⠳⢶⣦⡶⠞⢻⡟⡸⠟⠁⢠⠟⠉⠉⠙⠿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⡴\r\n"
                    + "⠀⠀⢸⣿⡇⠀⠀⣀⣠⠀⢀⡀⠸⣹⠇⠀⣰⡟⡀⠀⠈⠛⠻⢿⣻⣿⡿⠀⠀⠀⠀⠀⠀⡠⠁\r\n"
                    + "⠀⠀⢸⣿⣇⣴⢿⣿⣿⣿⣮⣿⣷⡟⠀⣰⣿⢰⠀⣀⠀⠀⠀⢀⣉⣿⡇⠀⠀⠀⠀⠀⣸⠃⠀\r\n"
                    + "⠀⠀⢸⣿⡟⣯⠸⣿⣿⣿⣿⢈⣿⡇⣼⣿⠇⣸⡦⣙⣷⣦⣴⣯⠿⠛⢷⡀⠀⠀⠀⣰⡟⠀⠀\r\n"
                    + "⠀⠀⠘⣿⣿⡸⣷⣝⠻⠟⢋⣾⣟⣰⡏⣠⣤⡟⠀⠀⠈⠉⠁⠀⠀⠀⠀⢻⣶⠀⢀⣿⠁⠀⠀\r\n"
                    + "⠀⠀⠀⢸⡿⣿⣦⣽⣛⣛⣛⣭⣾⣷⡶⠞⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⣿⡟⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡀⠁⢸⢻⠁⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣤⣤⣀⣀⣀⣀⣀⣠⣤⠶⠛⠁⢀⣾⡟⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⢿⣻⣿⣿⣿⣿⣿⣿⣎⣿⡅⠀⠈⠉⠉⠉⠉⠉⠁⠀⠀⠀⠀⣼⣿⠁⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠈⢻⣿⣿⣿⣿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⡷⠟⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠙⢿⣿⣿⠻⢿⣿⣿⣟⣂⣀⣀⣀⣀⣀⣀⣤⠴⠋⠁⣾⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠀⠈⢻⣿⣷⣷⡄⠀⠀⠀⠉⠉⠉⠉⠉⠀⠀⠀⢀⡞⠁⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⣿⣿⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣷⣤⣤⣤⣤⣄⣤⣤⡤⠴⠞⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀" +
                    "💥 TIRO EFETIVO! 💥\n"
            );
        } else {
            System.out.println(
                    "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⡀⠀⢄⠀⡌⠀⡎⡆⣲⠤⠀⡀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⡀⡀⠄⠀⠢⠄⡠⣁⠁⢘⠡⣑⢺⡊⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⠀⠀⠁⠀⣀⠀⠆⡇⡍⣇⣦⡆⠢⠶⡇⢋⢃⡖⠂⠂⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠀⡄⢀⠁⠀⡀⠀⠀⡖⣄⡦⡢⡟⠮⡟⠋⡇⠁⠊⠄⠀⠂⢂⠊⠀⠂⠀⠄⢀⠀⠀⠀⠀⠄⠀⠀⠀⠠⠀⠀⡀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⡀⠀⡂⠀⠀⠅⠀⠀⡏⡁⡐⠙⠉⣃⣧⡛⡏⣀⢆⣡⣐⠃⡡⣄⡈⠁⣂⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠄⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠈⠁⠀⠄⡀⠊⠀⠂⠋⠁⡀⢷⣁⢝⢢⡅⣓⡋⡩⢇⠒⡃⠇⢠⠁⠄⢁⠂⠄⣐⣀⢀⠀⠀⠀⠀⠀⠂⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠠⠀⠅⠁⠠⠀⡈⠀⠄⡊⢒⡁⠆⣸⣇⢣⡌⣃⣹⣏⡙⣃⠅⡂⣫⠠⡤⡣⠧⡄⡁⠀⠤⠄⡠⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠃⠀⡂⢀⡌⠄⠉⡁⠆⢀⠔⠨⡰⣃⣫⠅⠦⣧⣬⢐⣲⢋⡃⡓⠄⢽⠩⠄⠏⡄⠄⢄⠀⠔⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠠⡄⠀⠁⠀⡁⠍⣃⢄⠂⣌⣕⢁⠏⠫⠏⣁⢄⠡⢃⠙⣝⢚⡎⡓⠉⡀⠓⡤⠔⢂⡐⠀⡀⡁⠈⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⣀⡄⢂⡎⣠⣅⠕⠁⢃⠀⡌⣀⠅⡀⣵⡑⡮⣥⡅⠿⠓⠉⡄⡇⠂⠀⠏⡔⠀⢅⠡⡈⣉⠒⠙⠂⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠐⠥⠊⠙⠡⠀⠄⠬⠠⢁⠠⡄⡈⡇⣁⠄⠁⠅⠇⡅⣯⡒⢙⢣⡅⡇⠕⠃⡃⣔⠀⡀⢂⠒⠀⠀⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠠⠆⠈⠂⠀⠁⠲⠀⡇⡁⡂⠀⠐⣂⡇⢔⡯⣪⣑⡂⠄⢎⠁⠢⡁⢂⠈⡥⠅⡊⠀⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⣀⠀⠀⣠⠀⠁⡠⡀⢁⡆⢒⢃⣁⡀⠆⣇⠘⠡⡹⠉⡁⠄⠁⠎⢀⠀⡊⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠀⠡⠀⠀⢀⠂⠀⠆⠇⠂⠐⠄⠀⠄⠄⣇⠱⠨⢉⡄⠆⡠⣇⠉⡃⠃⠁⡁⠈⡀⠀⠀⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠃⡀⠀⠀⠀⠀⡀⡀⠀⠀⠀⠀⠀⠀⠃⢯⠃⠓⠅⠄⠯⢺⢧⠈⠁⠁⠦⢀⢀⠀⠐⠄⠂⠒⠂⠊⠀⡇⢀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⡀⠀⠀⠂⠠⠀⠐⢠⡨⠀⡈⡴⣄⣛⠣⠒⠔⠆⢁⠄⡃⡈⠢⢀⠤⠠⡆⠐⠂⠁⠁⢂⠀⠄⡡⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠁⠀⠁⠀⢀⢈⠀⠄⢀⠀⠂⢒⡀⠄⠅⠈⢖⣂⠠⡁⡨⠈⠀⠁⠡⠀⠀⠀⠂⠔⠀⠀⠀⡄⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂⠀⠀⡋⠀⠀⠰⢁⠄⢀⠄⠏⠀⢀⠁⠂⢀⠁⠠⠈⠈⠀⢀⠀⠀⠀⠂⠈⠀⠀⠐⠀⣀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠀⠀⠋⠀⠀⠁⠀⠊⡃⠀⠂⠢⠡⠄⠀⠠⠈⠂⠀⡀⠀⠀⠈⠀⠀⠀⠀⠀⡀⠀⠂⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⠀⠀⠀⠀⠁⠁⠀⢁⠀⠀⠀⡀⠀⠀⠀⠠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
                    + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
                    + "💥 TIRO INEFETIVO! 💥\n"
            );
        }
    }

    private void clearScreen() {
        for (int i = 0; i < 20; i++) System.out.println();
    }

    private int alivePlayers() {
        int count = 0;
        for (Player p : players) {
            if (p.isAlive()) count++;
        }
        return count;
    }
    
    void resetGame() {
        players.clear();
        bulletsInChamber = 0;
        realBullets = 0;
        fakeBullets = 0;
    }
}