package Game;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        boolean playAgain = true;

        while (playAgain) {

            clearScreen();

        System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠛⠛⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\r\n"
        		+ "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠋⠁⣠⣴⣄⠀⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿\r\n"
        		+ "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠛⠁⢀⣴⣿⣿⣿⣿⡆⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠛⠉⠀⣠\r\n"
        		+ "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⠀⢀⣼⣿⣿⣿⣿⣿⣿⣿⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠁⢀⣠⣶⣿⡟\r\n"
        		+ "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠛⠁⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠉⠉⠙⠛⠛⠛⠿⠋⠀⣀⣴⣿⣿⣿⠋⣰\r\n"
        		+ "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⠀⡀⢠⣿⣿⣿⣿⣿⣿⣿⣿⡏⣩⣤⠄⣠⣶⣶⡶⢀⣤⡀⠀⣠⣾⣿⣿⣿⡿⢃⣼⣿\r\n"
        		+ "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠀⠐⣿⣿⣿⣿⣿⣿⣿⣿⣿⠏⣴⣿⢃⣾⣿⣿⢋⣴⣿⠟⣠⣿⣿⣿⣿⣿⣿⠁⠾⠿⣿\r\n"
        		+ "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⠸⣿⢃⣾⣿⣿⢃⣾⣿⠏⣴⣿⣿⣿⣿⣿⣿⣿⣴⠋⣠⣿\r\n"
        		+ "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠋⠉⠉⠀⣠⣿⣿⣿⣿⣿⠿⢿⣿⣿⣿⣿⣦⣠⣾⣿⣿⣧⡘⠿⠋⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡙⣿\r\n"
        		+ "⣿⣿⣿⣿⣿⡟⠁⠀⠈⠉⠛⠏⠀⣴⣤⣴⣿⣿⣿⡿⠋⠀⠀⠀⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣌\r\n"
        		+ "⣿⣿⡿⠋⠉⠁⢀⣿⡃⠀⠀⠀⠀⠙⠿⣿⣿⣿⣿⠁⠀⠀⠀⠀⢸⣿⣿⠿⠿⠿⠿⣿⣿⣿⣿⣿⣿⣿⡟⠁⠁⠀⠉⠙⢿⣿⣿⣿⣿⣿\r\n"
        		+ "⣿⠋⠀⣠⣶⣷⣾⣿⣿⣿⣄⠲⣤⣀⠀⠈⠙⠿⣿⡀⠀⠀⠀⣠⡞⣩⣴⣾⣿⣿⣿⣶⣬⣛⢿⣿⣿⡟⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⣿\r\n"
        		+ "⡇⠀⣴⣿⡿⠉⠉⠉⠻⣿⣿⣇⠠⢉⠻⢦⣄⠀⠈⠻⢷⣶⣿⡏⣾⡀⠿⣿⡿⠻⣿⣿⣿⠛⣧⡹⣿⣇⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿\r\n"
        		+ "⡇⠀⣿⣿⠀⠀⠀⠀⠀⢻⣿⡿⢸⣷⣬⡂⢍⠻⢶⣄⡀⠉⠛⢷⣿⣷⣦⣤⣴⣦⣈⣉⣁⣠⣾⡇⣿⣿⣦⣀⠀⠀⢀⣠⣿⣿⣿⣿⣿⣿\r\n"
        		+ "⡇⠀⣿⣿⣆⠀⠀⠀⣠⣿⣿⣧⢸⣿⣿⣿⣷⣬⣐⣬⡙⠢⠀⠀⠈⠛⠿⣿⣿⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\r\n"
        		+ "⡇⠀⣿⣿⣿⣿⠿⢿⡿⠿⠿⠟⢼⣿⣿⣿⣿⣿⣿⣿⣿⣶⠀⣷⠀⡄⠀⠈⠛⠛⠛⠛⠿⠿⣫⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\r\n"
        		+ "⡇⠀⣿⡛⢹⣇⠀⣠⡏⢘⣿⣿⣶⣌⠙⠻⢿⣿⣿⣿⣿⣿⠀⣿⠀⡇⢰⡆⣄⠀⠀⢤⡀⠀⠘⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\r\n"
        		+ "⡇⠀⢻⣷⣤⣙⣛⣋⣴⣿⠿⠟⣿⣿⢸⠀⡆⢈⢙⠻⢿⣿⠀⠿⠀⣿⢸⡇⣿⠀⣆⢠⣈⠃⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\r\n"
        		+ "⣇⠀⠀⢉⠛⠛⠛⠛⠋⠁⠤⡀⠈⠙⠘⠆⡇⢸⠈⣷⣦⣍⡀⠄⡀⠉⠈⠃⢿⠀⣿⢸⣭⣷⣦⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\r\n"
        		+ "⣿⣦⣄⣀⠀⠁⠀⠀⠀⠀⠀⠀⠉⠢⢄⡀⠀⠙⠀⢿⣿⣿⣿⣷⣤⣁⠢⠀⡀⠀⠙⢸⣿⣿⣿⡄⠀⢿⣿⣿⣿⡿⣿⣿⣿⣿⡿⠿⠿⠛\r\n"
        		+ "⣿⣿⣿⣿⣷⣦⣤⣀⠀⠀⠀⠀⠀⠀⠀⠈⠑⠂⢄⡀⠈⠙⠻⢿⣿⣿⣿⣶⣬⣑⠀⠸⢿⣿⣿⡇⠀⢸⡛⣿⣿⣷⢠⡉⠻⢿⠇⢠⣦⣴\r\n"
        		+ "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⡄⠀⠀⠀⠀⠀⠀⠀⠀⠈⠑⠂⠀⠀⠉⠉⠙⠛⠿⢿⣿⣶⣦⣌⡉⠃⠀⠈⣿⣦⣍⣫⣾⣿⣷⣤⣴⣿⣿⣿\r\n"
        		+ "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⣰⣿⣿⣿⣷⣦⡀⢠⣴⣾⣿⣿⡿⣷⣶⣶⣤⡀⠈⠙⣿⣿⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\r\n"
        		+ "⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⠀⢀⣿⣿⣿⣿⣿⣿⠀⣾⣿⣿⡿⣫⣾⣿⣿⣿⣿⣿⣷⣄⠈⠙⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\r\n"
        		+ "⣬⣙⠻⣿⣿⣿⣿⣿⣿⡇⠀⢸⣿⣿⣿⣿⣿⣿⠀⠹⣿⢿⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
        System.out.println("==================== BUCKSHOT ROULETTE ====================");

	        Game game = new Game();
	
	        for (int i = 1; i <= 3; i++) {
	            System.out.print("Digite o nome do jogador " + i + ": ");
	            String name = scanner.nextLine();
	            game.addPlayer(new Player(name));
	        }
	
	        game.start(); // <<< RODA UMA PARTIDA
	
	        // ===== PERGUNTA SE QUER JOGAR DE NOVO =====
	        System.out.println();
	        System.out.println("Deseja jogar novamente?");
	        System.out.println("1 - Sim");
	        System.out.println("2 - Não");
	        System.out.print("Escolha: ");
	
	        String choice = scanner.nextLine();
	
	        if (!choice.equals("1")) {
	            playAgain = false;
	        }
	    }
	
	    System.out.println();
	    System.out.println("Obrigado por jogar Buckshot Roulette! 💀");
	    scanner.close();
	}
	
	private static void clearScreen() {
	    for (int i = 0; i < 50; i++) {
	        System.out.println();
	    }
	}
}