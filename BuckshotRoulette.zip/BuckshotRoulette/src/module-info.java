/**
 * 
 */
/**
 * 
 */
module BuckshotRoulette {
}